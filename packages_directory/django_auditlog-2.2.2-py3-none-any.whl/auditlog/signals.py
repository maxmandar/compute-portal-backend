import django.dispatch

accessed = django.dispatch.Signal()
