SECRET_KEY = "nope"
STATIC_URL = "/static/"
INSTALLED_APPS = ["codemirror2"]
