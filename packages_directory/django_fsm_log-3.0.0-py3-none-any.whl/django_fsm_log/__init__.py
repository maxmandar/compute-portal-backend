default_app_config = 'django_fsm_log.apps.DjangoFSMLogAppConfig'
